from django.contrib import admin
from locations.models import Country,State,Cities


admin.site.register(Country)
admin.site.register(State)
admin.site.register(Cities)
