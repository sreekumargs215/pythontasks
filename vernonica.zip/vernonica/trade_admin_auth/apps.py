from django.apps import AppConfig


class TradeAdminAuthConfig(AppConfig):
    name = 'trade_admin_auth'
