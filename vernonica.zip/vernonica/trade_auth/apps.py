from django.apps import AppConfig


class TradeAuthConfig(AppConfig):
    name = 'trade_auth'
