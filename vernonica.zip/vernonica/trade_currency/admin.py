from django.contrib import admin
from trade_currency.models import TradeCurrency,TradePairs



admin.site.register(TradeCurrency)
admin.site.register(TradePairs)
