from django.apps import AppConfig


class TradeCurrencyConfig(AppConfig):
    name = 'trade_currency'
