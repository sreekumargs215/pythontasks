from django.apps import AppConfig


class TradeMasterConfig(AppConfig):
    name = 'trade_master'
