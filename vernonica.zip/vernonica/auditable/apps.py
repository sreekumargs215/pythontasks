from django.apps import AppConfig


class AuditableConfig(AppConfig):
    name = 'auditable'
