from django.contrib.auth.models import User
from .forms import Formdetails
from .models import Register
from django.contrib.auth import login, authenticate
from django.contrib.auth import logout
from django.contrib.messages import constants as messages
from django.shortcuts import render,redirect
from datetime import timedelta, datetime
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt


def user_access(view_fun):
    def _wrapper_view(request,*args,**kwargs):
        if request.user.is_active:
            return view_fun(request,*args,**kwargs)
        else:
            return redirect('/')
    return  _wrapper_view

def admin_access(view_fun):
    def _wrapper_view(request,*args,**kwargs):
        if request.user.is_superuser:
            return view_fun(request,*args,**kwargs)
        else:
            return redirect('/')
    return  _wrapper_view
@user_access
def index(request):
    if request.user.is_authenticated:

        user9=Register.objects.get(user_id=request.user.id)
        return render(request,"index.html",{'tower':user9})

    return render(request,"index.html")

def register(request):
    if request.method =='POST':
        data=request.POST
        userform=Formdetails(request.POST)
        if userform.is_valid():
            userform.save()
            messages.success(request, "Registration Successfull :)")
            print(userform.instance.id)
            email=data['email']
            Register.objects.create(user_id=userform.instance.id,email=email)
            print(data)
            return redirect("/login")
        else:                
                                          
            print(userform.errors)
    return render(request,"register.html")

def login1(request):
        print(request.user)
        print(request.POST)
        if request.method == 'POST':
            username = request.POST['username']
            password1 = request.POST['password']
            user = authenticate(request, username=username, password=password1)
            print(user)
            if user is not None:
                    login(request,user)
                    messages.success(request,"Login Successfull")
                    return redirect('/index')
            else:
                msg="Invalid username"
                return render(request, 'login.html')
        return render(request,"login.html")
@user_access
def profile(request):
    user=Register.objects.get(user_id=request.user.id)
    return render(request,"profile.html",{'user':user})
@user_access
def icons1(request):
    user1=Register.objects.get(user_id=request.user.id)
    return render(request,"icons.html",{'user':user1})
@user_access
def forms1(request):
    user2=Register.objects.get(user_id=request.user.id)
    return render(request,"forms.html",{'user':user2})
@user_access
def calender1(request):
    user3=Register.objects.get(user_id=request.user.id)
    return render(request,"calendar.html",{'user':user3})
@user_access
def table1(request):
    user4=Register.objects.get(user_id=request.user.id)
    return render(request,"tables.html",{'user':user4})
@user_access
def dashboard(request):
    user5=Register.objects.get(user_id=request.user.id)
    return render(request,"index.html",{'user':user5})

def logoutdata(request):
    logout(request)
    messages.error(request,"You Are Logged Out :(")
    return redirect('/')